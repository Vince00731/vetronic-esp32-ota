#!/bin/bash

port=/dev/ttyUSB0

name=firmware.bin

./stm32loader.py -p $port -b 115200 -a 0x8000000 -E 126 -w firmware.bin

echo ""
echo ""
echo "Pressez une touche"
read
